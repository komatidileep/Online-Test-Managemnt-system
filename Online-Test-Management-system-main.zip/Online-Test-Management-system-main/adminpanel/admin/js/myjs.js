$(function(){
	$('a[rel*=facebox]').facebox();
});